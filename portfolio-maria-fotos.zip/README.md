# Portfólio profissional — Maria Régia Lima

Site estático para GitHub Pages, com fotografias e materiais enviados pela autora.

## Publicação

Envie `index.html`, `style.css`, `script.js` e a pasta `imagens/` para a **raiz** do repositório `lmmaria.github.io`.

Em **Settings → Pages**, selecione `Deploy from a branch`, branch `main`, pasta `/ (root)`.

## Créditos e observações

Imagens dos projetos fornecidas pela autora. A arte do Renova PVC representa uma proposta de produto; características exibidas na arte não equivalem a ensaios laboratoriais certificados.
