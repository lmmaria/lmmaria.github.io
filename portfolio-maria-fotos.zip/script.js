document.addEventListener('DOMContentLoaded', () => {
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();

  const menu = document.getElementById('menu');
  const links = document.getElementById('links');
  if (menu && links) {
    menu.addEventListener('click', () => {
      const isOpen = links.classList.toggle('open');
      menu.setAttribute('aria-expanded', String(isOpen));
      menu.setAttribute('aria-label', isOpen ? 'Fechar menu' : 'Abrir menu');
    });
    links.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      links.classList.remove('open');
      menu.setAttribute('aria-expanded', 'false');
    }));
  }

  const progress = document.getElementById('progress');
  const updateProgress = () => {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    if (progress) progress.style.width = (max > 0 ? (window.scrollY / max) * 100 : 0) + '%';
  };
  window.addEventListener('scroll', updateProgress, { passive: true });
  updateProgress();

  const revealItems = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });
    revealItems.forEach(item => observer.observe(item));
  } else revealItems.forEach(item => item.classList.add('visible'));

  const projects = {
    heat: { category: 'TRANSFERÊNCIA DE CALOR · PROTÓTIPO ACADÊMICO', title: 'Trocador de Calor Casco e Tubos — TC-001', description: 'Desenvolvimento de protótipo acadêmico de trocador de calor do tipo casco e tubos. O trabalho envolveu planejamento, seleção de materiais, montagem de componentes em PVC e documentação do processo de construção.' },
    pvc: { category: 'MATERIAIS · SUSTENTABILIDADE', title: 'Renova PVC', description: 'Proposta acadêmica de painel biocompósito sustentável a partir de finos de PVC. O projeto explora alternativas de reaproveitamento de resíduos e possíveis aplicações em materiais, sem pressupor desempenho industrial já comprovado.' },
    water: { category: 'HIDRÁULICA · FENÔMENOS DE TRANSPORTE', title: 'Sistema de Bombeamento e Distribuição de Água', description: 'Estudo acadêmico de transporte de fluidos em sistema de bombeamento e distribuição de água, contemplando análise de escoamento, perdas de carga e condições operacionais.' }
  };
  const dialog = document.getElementById('project-dialog');
  document.querySelectorAll('[data-project]').forEach(button => {
    button.addEventListener('click', () => {
      const item = projects[button.dataset.project];
      if (!item || !dialog) return;
      document.getElementById('dialog-category').textContent = item.category;
      document.getElementById('dialog-title').textContent = item.title;
      document.getElementById('dialog-description').textContent = item.description;
      if (typeof dialog.showModal === 'function') dialog.showModal();
    });
  });
  document.getElementById('dialog-close')?.addEventListener('click', () => dialog?.close());
  dialog?.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
});
